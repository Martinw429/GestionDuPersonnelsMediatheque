-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 27 mai 2026 à 11:17
-- Version du serveur : 8.4.7
-- Version de PHP : 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `mediatheque`
--
CREATE DATABASE IF NOT EXISTS `mediatheque` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `mediatheque`;

-- --------------------------------------------------------

--
-- Structure de la table `absence`
--

DROP TABLE IF EXISTS `absence`;
CREATE TABLE IF NOT EXISTS `absence` (
  `idpersonnel` int NOT NULL,
  `datedebut` datetime NOT NULL,
  `datefin` datetime DEFAULT NULL,
  `idmotif` int NOT NULL,
  PRIMARY KEY (`idpersonnel`,`datedebut`),
  KEY `idmotif` (`idmotif`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `absence`
--

INSERT INTO `absence` (`idpersonnel`, `datedebut`, `datefin`, `idmotif`) VALUES
(1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2),
(8, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2),
(5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 3),
(9, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 3),
(6, '2026-06-26 00:00:00', '2011-01-27 00:00:00', 1),
(1, '2014-01-26 00:00:00', '2030-06-26 00:00:00', 3),
(5, '2029-05-25 00:00:00', '2001-11-25 00:00:00', 2),
(5, '2022-11-25 00:00:00', '2030-08-26 00:00:00', 3),
(3, '2028-01-27 00:00:00', '2009-05-26 00:00:00', 2),
(2, '2007-09-26 00:00:00', '2016-10-26 00:00:00', 2),
(4, '2011-05-26 00:00:00', '2023-04-27 00:00:00', 1),
(2, '2023-10-26 00:00:00', '2027-07-26 00:00:00', 3),
(8, '2028-07-25 00:00:00', '2020-12-26 00:00:00', 4),
(10, '2016-03-26 00:00:00', '2028-07-26 00:00:00', 4),
(4, '2030-11-26 00:00:00', '2029-10-26 00:00:00', 1),
(6, '2023-07-25 00:00:00', '2023-03-27 00:00:00', 4),
(9, '2010-01-26 00:00:00', '2003-09-26 00:00:00', 2),
(8, '2010-03-26 00:00:00', '2001-02-26 00:00:00', 3),
(4, '2014-10-25 00:00:00', '2004-11-25 00:00:00', 2),
(3, '2006-01-26 00:00:00', '2009-03-26 00:00:00', 3),
(3, '2014-11-25 00:00:00', '2030-01-27 00:00:00', 2),
(9, '2007-11-26 00:00:00', '2004-06-26 00:00:00', 4),
(8, '2020-05-26 00:00:00', '2001-04-26 00:00:00', 3),
(9, '2001-04-26 00:00:00', '2019-10-25 00:00:00', 1),
(9, '2007-09-26 00:00:00', '2007-04-26 00:00:00', 2),
(6, '2025-05-25 00:00:00', '2013-01-26 00:00:00', 1),
(8, '2002-02-26 00:00:00', '2028-12-25 00:00:00', 4),
(3, '2028-02-26 00:00:00', '2021-12-25 00:00:00', 4),
(6, '2009-02-26 00:00:00', '2012-07-26 00:00:00', 2),
(1, '2001-07-26 00:00:00', '2010-05-26 00:00:00', 3),
(8, '2008-09-26 00:00:00', '2010-01-27 00:00:00', 2),
(3, '2020-12-25 00:00:00', '2024-09-26 00:00:00', 2),
(5, '2007-08-25 00:00:00', '2012-03-26 00:00:00', 2),
(7, '2028-11-25 00:00:00', '2014-02-27 00:00:00', 3),
(2, '2014-07-25 00:00:00', '2012-10-25 00:00:00', 4),
(3, '2016-01-26 00:00:00', '2020-06-25 00:00:00', 2),
(7, '2014-04-26 00:00:00', '2020-10-26 00:00:00', 2),
(9, '2007-10-26 00:00:00', '2020-09-26 00:00:00', 4),
(3, '2002-04-26 00:00:00', '2008-08-25 00:00:00', 2),
(9, '2008-03-27 00:00:00', '2011-11-25 00:00:00', 3),
(6, '2012-12-25 00:00:00', '2020-12-26 00:00:00', 2),
(6, '2026-08-26 00:00:00', '2021-08-25 00:00:00', 1),
(7, '2016-10-26 00:00:00', '2019-11-26 00:00:00', 4),
(6, '2011-02-27 00:00:00', '2030-10-26 00:00:00', 2),
(5, '2013-07-26 00:00:00', '2007-05-27 00:00:00', 3),
(5, '2023-12-25 00:00:00', '2027-08-25 00:00:00', 4),
(5, '2006-07-25 00:00:00', '2023-02-27 00:00:00', 4),
(4, '2009-02-26 00:00:00', '2026-08-26 00:00:00', 2),
(3, '2031-03-26 00:00:00', '2001-09-25 00:00:00', 1),
(4, '2013-05-27 00:00:00', '2001-06-25 00:00:00', 1),
(8, '2029-09-25 00:00:00', '2011-06-26 00:00:00', 1),
(4, '2031-10-25 00:00:00', '2004-08-25 00:00:00', 1),
(7, '2023-11-25 00:00:00', '2015-01-27 00:00:00', 2),
(8, '2014-01-26 00:00:00', '2006-05-27 00:00:00', 4),
(0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Structure de la table `motif`
--

DROP TABLE IF EXISTS `motif`;
CREATE TABLE IF NOT EXISTS `motif` (
  `idmotif` int NOT NULL AUTO_INCREMENT,
  `libelle` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idmotif`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `motif`
--

INSERT INTO `motif` (`idmotif`, `libelle`) VALUES
(1, 'vacances'),
(2, 'maladie'),
(3, 'motif familial'),
(4, 'congé parental');

-- --------------------------------------------------------

--
-- Structure de la table `personnel`
--

DROP TABLE IF EXISTS `personnel`;
CREATE TABLE IF NOT EXISTS `personnel` (
  `idpersonnel` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prenom` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tel` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mail` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idservice` int NOT NULL,
  PRIMARY KEY (`idpersonnel`),
  KEY `idservice` (`idservice`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `personnel`
--

INSERT INTO `personnel` (`idpersonnel`, `nom`, `prenom`, `tel`, `mail`, `idservice`) VALUES
(2, 'Gilbert', 'May', '07 73 64 23 12', 'ligula.eu@outlook.org', 2),
(3, 'Shelton', 'Noble', '01 74 34 25 66', 'nisi.cum@aol.ca', 2),
(4, 'Le', 'Hayes', '08 98 74 44 86', 'enim.commodo@hotmail.com', 2),
(5, 'Strickland', 'Hunter', '06 48 54 54 72', 'inceptos.hymenaeos@protonmail.net', 3),
(6, 'Middleton', 'Cooper', '02 21 73 57 25', 'vitae.aliquet@icloud.couk', 2),
(7, 'Wiggins', 'Logan', '05 46 28 35 80', 'nunc.quis@protonmail.com', 1),
(8, 'Simmons', 'Christine', '06 34 67 55 76', 'eu.odio@yahoo.net', 1),
(9, 'Collins', 'Candace', '05 72 09 88 58', 'sem.magna@aol.couk', 2),
(10, 'Espinoza', 'Bo', '01 73 11 83 70', 'class@google.org', 2),
(26, 'Howard', 'Robert', '06 26 26 26 26', 'Hrob@hotmail.com', 1),
(27, 'Albin', 'Michel', '06 25 24 27 78', 'AlbinM@gmail.fr', 2);

-- --------------------------------------------------------

--
-- Structure de la table `responsable`
--

DROP TABLE IF EXISTS `responsable`;
CREATE TABLE IF NOT EXISTS `responsable` (
  `login` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pwd` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `responsable`
--

INSERT INTO `responsable` (`login`, `pwd`) VALUES
('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9');

-- --------------------------------------------------------

--
-- Structure de la table `service`
--

DROP TABLE IF EXISTS `service`;
CREATE TABLE IF NOT EXISTS `service` (
  `idservice` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idservice`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `service`
--

INSERT INTO `service` (`idservice`, `nom`) VALUES
(1, 'administractif'),
(2, 'médiation culturelle'),
(3, 'prêt');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

CREATE USER 'root'@'localhost' IDENTIFIED BY 'root';
GRANT ALL PRIVILEGES ON ma_base.* TO 'root'@'localhost';
FLUSH PRIVILEGES;